
import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { AuthProvider, useAuth } from '@/contexts/SupabaseAuthContext';
import { Toaster } from '@/components/ui/toaster';
import { FullPageLoader } from '@/components/ui/loading-spinner';
import { ThemeToggle } from '@/components/ThemeToggle';
import { LanguageSwitcher } from '@/components/LanguageSwitcher';
import { useLanguage } from '@/contexts/LanguageContext';

// Pages
import SchoolSelectionPage from '@/pages/SchoolSelectionPage';
import RoleSelectionPage from '@/pages/RoleSelectionPage';
import ParentLoginPage from '@/pages/ParentLoginPage';
import TeacherLoginPage from '@/pages/TeacherLoginPage';
import DisciplineMasterLoginPage from '@/pages/DisciplineMasterLoginPage';
import VicePrincipalLoginPage from '@/pages/VicePrincipalLoginPage';
import AdministratorLoginPage from '@/pages/AdministratorLoginPage';
import ParentDashboard from '@/pages/ParentDashboard';
import TeacherDashboard from '@/pages/TeacherDashboard';
import DisciplineDashboard from '@/pages/DisciplineDashboard';
import VicePrincipalDashboard from '@/pages/VicePrincipalDashboard';
import AdminDashboard from '@/pages/AdminDashboard';
import AboutUsPage from '@/pages/AboutUsPage';
import ContactUsPage from '@/pages/ContactUsPage';
import CloudAIPage from '@/pages/CloudAIPage';
import ProtectedRoute from '@/components/ProtectedRoute';

// Helper component to handle redirection logic
const AppContent = () => {
  const { user, loading, isAuthenticated } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const location = useLocation();

  // Automatic Redirection Effect
  useEffect(() => {
    if (!loading && isAuthenticated) {
      // If user is on a public path (login, selection, etc.)
      // Exclude info pages from auto-redirect
      const publicPaths = ['/', '/role-selection', '/login'];
      const isPublicPath = publicPaths.some(path => location.pathname.startsWith(path));
      const isInfoPage = ['/about', '/contact'].includes(location.pathname);

      if (isPublicPath && !isInfoPage) {
        // Retrieve role from secure storage (using localStorage as implemented in Login pages)
        const role = localStorage.getItem('userRole');
        
        if (role) {
          const dashboardMap = {
            'parent': '/dashboard/parent',
            'teacher': '/dashboard/teacher',
            'discipline': '/dashboard/discipline',
            'vice_principal': '/dashboard/vice-principal', // normalization check
            'vice-principal': '/dashboard/vice-principal',
            'administrator': '/dashboard/administrator',
            'admin': '/dashboard/administrator'
          };

          const targetPath = dashboardMap[role];
          if (targetPath) {
             console.log(`Auto-redirecting ${role} to ${targetPath}`);
             navigate(targetPath, { replace: true });
          }
        }
      }
    }
  }, [loading, isAuthenticated, location.pathname, navigate]);

  if (loading) {
    return <FullPageLoader text={t('verifyingSession')} />;
  }

  // Determine if we are on a dashboard page
  const isDashboard = location.pathname.startsWith('/dashboard');

  return (
    <div className="min-h-screen bg-background relative selection:bg-primary/30">
      
      {/* Global Persistent Controls - Top Right */}
      {/* CONDITIONAL RENDERING: Only show these global controls if NOT on a dashboard.
          Dashboards have their own internal layout controls (Sidebar/Header).
          This prevents duplicate buttons appearing on screen. */}
      {!isDashboard && (
        <div className="fixed top-4 right-4 z-[100] flex items-center gap-2 md:gap-3 animate-in fade-in slide-in-from-top-4 duration-700 delay-300">
          <LanguageSwitcher />
          <ThemeToggle />
        </div>
      )}

      <Routes>
        {/* Public Pages */}
        <Route path="/" element={<SchoolSelectionPage />} />
        <Route path="/about" element={<AboutUsPage />} />
        <Route path="/contact" element={<ContactUsPage />} />
        
        {/* Semi-Private Page - Accessible if logged in, but we handle auth inside or just let it render */}
        <Route path="/cloud-ai" element={<CloudAIPage />} />

        <Route path="/role-selection/:schoolId" element={<RoleSelectionPage />} />
        <Route path="/login/parent/:schoolId" element={<ParentLoginPage />} />
        <Route path="/login/teacher/:schoolId" element={<TeacherLoginPage />} />
        <Route path="/login/discipline/:schoolId" element={<DisciplineMasterLoginPage />} />
        <Route path="/login/vice-principal/:schoolId" element={<VicePrincipalLoginPage />} />
        <Route path="/login/administrator/:schoolId" element={<AdministratorLoginPage />} />
        
        {/* Parent Routes */}
        <Route 
          path="/dashboard/parent/*" 
          element={
            <ProtectedRoute role="parent">
              <ParentDashboard />
            </ProtectedRoute>
          } 
        />

        {/* Teacher Routes */}
        <Route 
          path="/dashboard/teacher/*" 
          element={
            <ProtectedRoute role="teacher">
              <TeacherDashboard />
            </ProtectedRoute>
          } 
        />

        {/* Discipline Master Routes */}
        <Route 
          path="/dashboard/discipline/*" 
          element={
            <ProtectedRoute role="discipline">
              <DisciplineDashboard />
            </ProtectedRoute>
          } 
        />

        {/* Vice Principal Routes */}
        <Route 
          path="/dashboard/vice-principal/*" 
          element={
            <ProtectedRoute role="vice-principal">
              <VicePrincipalDashboard />
            </ProtectedRoute>
          } 
        />

        {/* Administrator Routes */}
        <Route 
          path="/dashboard/administrator/*" 
          element={
            <ProtectedRoute role="administrator">
              <AdminDashboard />
            </ProtectedRoute>
          } 
        />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      <Toaster />
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <Router>
        <Helmet>
          <title>CloudCampus - Modern School Management</title>
          <meta name="description" content="CloudCampus: The future of school administration" />
        </Helmet>
        <AppContent />
      </Router>
    </AuthProvider>
  );
}

export default App;
