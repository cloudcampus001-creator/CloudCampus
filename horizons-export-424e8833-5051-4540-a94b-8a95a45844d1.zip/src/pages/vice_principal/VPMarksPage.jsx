import React, { useState, useEffect } from 'react';
import { FileCheck, Search, Loader2, User } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Helmet } from 'react-helmet';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';

const VPMarksPage = ({ selectedClass }) => {
  const [marks, setMarks] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!selectedClass) return;

    const fetchMarks = async () => {
      setLoading(true);
      try {
        // Fetch marks for the selected class
        // Join with students to get names
        // Note: Supabase JOIN syntax requires properly defined foreign keys.
        // Assuming student_marks has student_matricule FK to students table.
        
        const { data, error } = await supabase
          .from('student_marks')
          .select(`
            *,
            students!inner ( name )
          `)
          .eq('class_id', selectedClass)
          .order('created_at', { ascending: false })
          .limit(50);

        if (error) throw error;
        setMarks(data || []);

      } catch (err) {
        console.error("Error fetching marks", err);
      } finally {
        setLoading(false);
      }
    };

    fetchMarks();
  }, [selectedClass]);

  if (!selectedClass) {
    return (
      <div className="flex flex-col items-center justify-center h-[50vh] text-muted-foreground">
        <FileCheck className="w-16 h-16 mb-4 opacity-20" />
        <p>Please select a class to review marksheets.</p>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Marksheet Review - Vice Principal</title>
      </Helmet>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Marksheet Review</h1>
          <p className="text-muted-foreground">Verify grades submitted by teachers.</p>
        </div>

        <Card className="glass">
          <CardHeader>
            <CardTitle>Recent Submissions</CardTitle>
            <CardDescription>Latest marks uploaded for this class.</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="w-8 h-8 animate-spin text-pink-500" />
              </div>
            ) : marks.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                 No marks found for this class yet.
              </div>
            ) : (
              <div className="relative w-full overflow-auto">
                 <table className="w-full caption-bottom text-sm text-left">
                    <thead className="[&_tr]:border-b [&_tr]:border-white/10">
                       <tr className="border-b border-white/10 transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted">
                          <th className="h-12 px-4 align-middle font-medium text-muted-foreground">Student</th>
                          <th className="h-12 px-4 align-middle font-medium text-muted-foreground">Subject</th>
                          <th className="h-12 px-4 align-middle font-medium text-muted-foreground">Assessment</th>
                          <th className="h-12 px-4 align-middle font-medium text-muted-foreground">Mark</th>
                          <th className="h-12 px-4 align-middle font-medium text-muted-foreground">Date</th>
                       </tr>
                    </thead>
                    <tbody className="[&_tr:last-child]:border-0">
                       {marks.map((mark) => (
                          <tr key={mark.id} className="border-b border-white/10 transition-colors hover:bg-white/5">
                             <td className="p-4 align-middle font-medium">{mark.students?.name}</td>
                             <td className="p-4 align-middle">{mark.subject}</td>
                             <td className="p-4 align-middle">{mark.assessment_name}</td>
                             <td className="p-4 align-middle">
                                <Badge variant={mark.mark / mark.total_marks >= 0.5 ? 'success' : 'destructive'}>
                                   {mark.mark} / {mark.total_marks}
                                </Badge>
                             </td>
                             <td className="p-4 align-middle text-muted-foreground">{new Date(mark.created_at).toLocaleDateString()}</td>
                          </tr>
                       ))}
                    </tbody>
                 </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </>
  );
};

export default VPMarksPage;