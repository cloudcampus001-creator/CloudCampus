import React, { useState, useEffect } from 'react';
import { BookOpen, User, Calendar, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Helmet } from 'react-helmet';
import { Badge } from '@/components/ui/badge';

const VPLogbookPage = ({ selectedClass }) => {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!selectedClass) return;

    const fetchLogs = async () => {
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from('e_logbook_entries')
          .select('*, teachers(name)')
          .eq('class_id', selectedClass)
          .order('created_at', { ascending: false });
        
        if (error) throw error;
        setLogs(data || []);
      } catch (err) {
        console.error("Error fetching logs", err);
      } finally {
        setLoading(false);
      }
    };

    fetchLogs();
  }, [selectedClass]);

  if (!selectedClass) {
    return (
      <div className="flex flex-col items-center justify-center h-[50vh] text-muted-foreground">
        <BookOpen className="w-16 h-16 mb-4 opacity-20" />
        <p>Please select a class to view logbook entries.</p>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Logbook Review - Vice Principal</title>
      </Helmet>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">E-Logbook Review</h1>
          <p className="text-muted-foreground">Monitoring daily academic activities.</p>
        </div>

        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-pink-500" />
          </div>
        ) : logs.length === 0 ? (
          <Card className="glass">
            <CardContent className="flex flex-col items-center justify-center py-12 text-muted-foreground">
              <BookOpen className="w-12 h-12 mb-4 opacity-20" />
              <p>No logbook entries found for this class.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {logs.map((log) => (
              <Card key={log.id} className="glass hover:border-pink-500/50 transition-all">
                <CardHeader className="pb-2">
                   <div className="flex justify-between items-start">
                     <Badge variant="outline">{log.subject}</Badge>
                     <span className="text-xs text-muted-foreground">{new Date(log.created_at).toLocaleDateString()}</span>
                   </div>
                   <CardTitle className="text-lg mt-2">{log.topic}</CardTitle>
                   <CardDescription className="line-clamp-1">{log.sub_topics}</CardDescription>
                </CardHeader>
                <CardContent>
                   <div className="flex items-center gap-2 text-sm text-muted-foreground mt-2 pt-2 border-t border-white/5">
                      <User className="w-4 h-4" /> 
                      <span>Teacher: {log.teachers?.name || 'Unknown'}</span>
                   </div>
                   {log.status && (
                     <div className="mt-2">
                        <Badge variant={log.status === 'completed' ? 'success' : 'warning'} className="text-[10px] uppercase">
                          {log.status}
                        </Badge>
                     </div>
                   )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </>
  );
};

export default VPLogbookPage;