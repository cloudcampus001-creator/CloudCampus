import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { 
  CalendarClock, Plus, Trash2, Loader2, Clock, MapPin
} from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const AdminTimetablePage = () => {
  const schoolId = localStorage.getItem('schoolId');
  const { toast } = useToast();
  
  const [classes, setClasses] = useState([]);
  const [teachers, setTeachers] = useState([]);
  const [selectedClass, setSelectedClass] = useState(null);
  const [timetable, setTimetable] = useState([]);
  const [loading, setLoading] = useState(false);
  
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [slotData, setSlotData] = useState({});
  const [saving, setSaving] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [slotToDelete, setSlotToDelete] = useState(null);

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

  useEffect(() => {
    const fetchMetadata = async () => {
      if (!schoolId) return;
      
      // Fetch classes
      const { data: cls } = await supabase.from('classes').select('id, name').eq('school_id', parseInt(schoolId));
      setClasses(cls || []);

      // Fetch teachers
      const { data: tch } = await supabase.from('teachers').select('id, name, subjects').eq('school_id', parseInt(schoolId));
      setTeachers(tch || []);
    };
    fetchMetadata();
  }, [schoolId]);

  useEffect(() => {
    if (selectedClass) {
      fetchTimetable();
    } else {
        setTimetable([]);
    }
  }, [selectedClass]);

  const fetchTimetable = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('timetables')
        .select('*')
        .eq('class_id', selectedClass)
        .eq('school_id', parseInt(schoolId));
      
      if (error) throw error;
      setTimetable(data || []);
    } catch (error) {
      console.error('Fetch error:', error);
      toast({ variant: 'destructive', title: 'Error', description: 'Failed to load timetable.' });
    } finally {
      setLoading(false);
    }
  };

  const handleAddSlot = (day) => {
    setSlotData({ day_of_week: day, start_time: '08:00', end_time: '09:00' });
    setIsDialogOpen(true);
  };

  const handleDeleteClick = (id) => {
    setSlotToDelete(id);
    setDeleteConfirmOpen(true);
  };

  const confirmDelete = async () => {
    if (!slotToDelete) return;
    try {
      const { error } = await supabase.from('timetables').delete().eq('id', slotToDelete);
      if (error) throw error;
      setTimetable(prev => prev.filter(t => t.id !== slotToDelete));
      setDeleteConfirmOpen(false);
      setSlotToDelete(null);
    } catch (error) {
      toast({ variant: 'destructive', title: 'Error', description: 'Could not delete slot.' });
    }
  };

  const handleSaveSlot = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const teacher = teachers.find(t => t.id.toString() === slotData.teacher_id);
      
      const payload = {
        school_id: parseInt(schoolId),
        class_id: parseInt(selectedClass),
        teacher_id: slotData.teacher_id,
        teacher_name: teacher ? teacher.name : 'Unknown',
        subject: slotData.subject,
        day_of_week: slotData.day_of_week,
        start_time: slotData.start_time,
        end_time: slotData.end_time
      };

      const { data, error } = await supabase.from('timetables').insert([payload]).select();
      if (error) throw error;

      setTimetable(prev => [...prev, data[0]]);
      setIsDialogOpen(false);
      toast({ title: 'Success', description: 'Timetable slot added.' });

    } catch (error) {
      console.error('Save error:', error);
      toast({ variant: 'destructive', title: 'Error', description: error.message });
    } finally {
      setSaving(false);
    }
  };

  const getSlotsForDay = (day) => {
    return timetable
      .filter(t => t.day_of_week === day)
      .sort((a, b) => a.start_time.localeCompare(b.start_time));
  };

  return (
    <>
      <Helmet>
        <title>Timetable Management - Admin</title>
      </Helmet>

      <div className="space-y-6 h-full flex flex-col">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Timetables</h1>
            <p className="text-muted-foreground">Manage class schedules and teacher assignments.</p>
          </div>
          
          <div className="w-full sm:w-64">
            <Select value={selectedClass?.toString()} onValueChange={val => setSelectedClass(parseInt(val))}>
              <SelectTrigger className="bg-background/60 border-indigo-500/30">
                <SelectValue placeholder="Select a Class to Manage" />
              </SelectTrigger>
              <SelectContent>
                {classes.map(c => (
                  <SelectItem key={c.id} value={c.id.toString()}>{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {!selectedClass ? (
           <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground min-h-[400px] glass rounded-xl">
              <CalendarClock className="w-16 h-16 mb-4 opacity-20" />
              <p>Please select a class from the dropdown above to view or edit its timetable.</p>
           </div>
        ) : loading ? (
           <div className="flex-1 flex items-center justify-center min-h-[400px]">
              <Loader2 className="w-8 h-8 animate-spin text-indigo-500" />
           </div>
        ) : (
           <div className="grid grid-cols-1 md:grid-cols-5 gap-4 overflow-x-auto pb-4">
              {days.map(day => (
                <div key={day} className="min-w-[250px] md:min-w-0">
                   <div className="bg-indigo-500/10 text-indigo-400 font-bold text-center py-2 rounded-t-lg border-t border-x border-indigo-500/20">
                      {day}
                   </div>
                   <div className="bg-card/30 border border-white/10 rounded-b-lg min-h-[500px] p-2 space-y-2">
                      {getSlotsForDay(day).map(slot => (
                         <div key={slot.id} className="group relative p-3 bg-background/50 hover:bg-background/80 border border-white/5 rounded-lg transition-all hover:shadow-lg">
                            <div className="flex justify-between items-start">
                               <Badge variant="outline" className="text-[10px]">{slot.start_time.slice(0,5)} - {slot.end_time.slice(0,5)}</Badge>
                               <Button variant="ghost" size="icon" className="h-5 w-5 opacity-0 group-hover:opacity-100 -mr-1 -mt-1" onClick={() => handleDeleteClick(slot.id)}>
                                  <Trash2 className="w-3 h-3 text-red-400" />
                               </Button>
                            </div>
                            <div className="mt-2 font-bold text-sm text-indigo-300">{slot.subject}</div>
                            <div className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                               <UserIcon className="w-3 h-3" /> {slot.teacher_name}
                            </div>
                         </div>
                      ))}
                      <Button variant="ghost" className="w-full border border-dashed border-white/10 hover:border-indigo-500/50 text-muted-foreground hover:text-indigo-400 mt-4" onClick={() => handleAddSlot(day)}>
                         <Plus className="w-4 h-4 mr-2" /> Add Slot
                      </Button>
                   </div>
                </div>
              ))}
           </div>
        )}

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Schedule Slot</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSaveSlot} className="space-y-4 py-4">
               <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Start Time</Label>
                    <Input type="time" value={slotData.start_time} onChange={e => setSlotData({...slotData, start_time: e.target.value})} required />
                  </div>
                  <div className="space-y-2">
                    <Label>End Time</Label>
                    <Input type="time" value={slotData.end_time} onChange={e => setSlotData({...slotData, end_time: e.target.value})} required />
                  </div>
               </div>

               <div className="space-y-2">
                  <Label>Teacher</Label>
                  <Select onValueChange={val => setSlotData({...slotData, teacher_id: val})}>
                     <SelectTrigger>
                        <SelectValue placeholder="Select Teacher" />
                     </SelectTrigger>
                     <SelectContent>
                        {teachers.map(t => (
                           <SelectItem key={t.id} value={t.id.toString()}>{t.name}</SelectItem>
                        ))}
                     </SelectContent>
                  </Select>
               </div>

               <div className="space-y-2">
                  <Label>Subject</Label>
                  <Input value={slotData.subject || ''} onChange={e => setSlotData({...slotData, subject: e.target.value})} placeholder="e.g., Mathematics" required />
               </div>

               <DialogFooter>
                 <Button type="submit" disabled={saving}>
                    {saving ? <Loader2 className="animate-spin mr-2" /> : null} Save
                 </Button>
               </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        <Dialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirm Delete</DialogTitle>
              <DialogDescription>
                Are you sure you want to remove this time slot? This action cannot be undone.
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDeleteConfirmOpen(false)}>Cancel</Button>
              <Button type="button" variant="destructive" onClick={confirmDelete}>Delete</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
};

function UserIcon(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
      <circle cx="12" cy="7" r="4" />
    </svg>
  )
}

export default AdminTimetablePage;