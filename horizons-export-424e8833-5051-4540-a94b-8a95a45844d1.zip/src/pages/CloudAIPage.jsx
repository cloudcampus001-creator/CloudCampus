import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Bot, Send, Sparkles, Trash2, User, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useLanguage } from '@/contexts/LanguageContext';
import { supabase } from '@/lib/customSupabaseClient';
import { Helmet } from 'react-helmet';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useToast } from '@/components/ui/use-toast';

const CloudAIPage = () => {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const { toast } = useToast();
  
  // State
  const [messages, setMessages] = useState([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef(null);
  const inputRef = useRef(null);

  // Initialize welcome message safely
  useEffect(() => {
    if (messages.length === 0) {
      setMessages([{ role: 'ai', text: t('aiWelcome') || "Hello! I'm your AI assistant. How can I help you today?" }]);
    }
  }, [t]);

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isLoading]);

  // Auto-focus input
  useEffect(() => {
    if (inputRef.current && !isLoading) {
      inputRef.current.focus();
    }
  }, [isLoading]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!inputValue.trim() || isLoading) return;

    const userText = inputValue.trim();
    const userMessage = { role: 'user', text: userText };
    
    // Optimistically update UI
    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    try {
      // Filter out initial welcome message or empty messages for context
      const history = messages
        .filter(m => m.text && m.text !== t('aiWelcome'))
        .map(m => ({
          role: m.role === 'ai' ? 'model' : 'user',
          parts: [{ text: m.text }] 
        }));
      
      // Add current message to history for the API call
      const currentPayload = {
        messages: [
          ...history,
          { role: 'user', parts: [{ text: userText }] }
        ]
      };

      const { data, error } = await supabase.functions.invoke('chat-with-gemini', {
        body: JSON.stringify(currentPayload)
      });

      if (error) {
        console.error('Supabase Function Error:', error);
        throw new Error(error.message || 'Failed to connect to AI service');
      }
      
      if (data?.error) {
        console.error('AI Model Error:', data.error);
        throw new Error(typeof data.error === 'string' ? data.error : data.error.message || 'AI Service Error');
      }
      
      if (data && data.text) {
        setMessages(prev => [...prev, { role: 'ai', text: data.text }]);
      } else {
        throw new Error('Empty response from AI');
      }

    } catch (error) {
      console.error('Chat Error:', error);
      
      let errorMessage = t('aiError') || 'Something went wrong. Please try again.';
      
      toast({
        variant: "destructive",
        title: "AI Error",
        description: errorMessage
      });
      
      // Add error message to chat for visibility
      setMessages(prev => [...prev, { 
        role: 'ai', 
        text: `⚠️ ${errorMessage} \n\n(${error.message})` 
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const clearChat = () => {
    setMessages([{ role: 'ai', text: t('aiWelcome') || "Hello! I'm your AI assistant. How can I help you today?" }]);
  };

  const formatBold = (text) => {
    if (!text) return null;
    // Safety check for text type
    const safeText = String(text);
    // Regex to split by **bold** markers
    const parts = safeText.split(/(\*\*.*?\*\*)/g);
    
    return parts.map((part, i) => {
        if (part.startsWith('**') && part.endsWith('**')) {
            return <strong key={i} className="font-bold text-indigo-200">{part.slice(2, -2)}</strong>;
        }
        return part;
    });
  };

  const formatText = (text) => {
    if (!text) return "";
    const safeText = String(text);
    
    return safeText.split('\n').map((str, i) => (
      <span key={i} className="min-h-[1.2em] block mb-1 last:mb-0">
        {formatBold(str)}
      </span>
    ));
  };

  return (
    <>
      <Helmet>
        <title>{t('cloudAI') || 'Cloud AI'} - CloudCampus</title>
      </Helmet>
      <div className="min-h-screen bg-background flex flex-col relative overflow-hidden">
        {/* Ambient Background */}
        <div className="absolute top-0 inset-x-0 h-64 bg-gradient-to-b from-indigo-500/10 to-transparent -z-10" />
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl -z-10" />
        <div className="absolute top-40 -left-20 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl -z-10" />

        {/* Header */}
        <header className="flex items-center justify-between p-4 border-b border-white/5 bg-background/50 backdrop-blur-md sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => navigate(-1)} className="rounded-full">
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-2">
              <div className="p-2 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg shadow-lg shadow-indigo-500/20">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="font-bold text-lg leading-none">{t('cloudAI') || 'Cloud AI'}</h1>
                <p className="text-xs text-muted-foreground">Powered by Gemini 1.5 Flash</p>
              </div>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={clearChat}
            className="text-muted-foreground hover:text-red-400"
            title="Clear conversation"
          >
            <Trash2 className="w-4 h-4 mr-2" />
            <span className="hidden sm:inline">{t('clearChat') || 'Clear Chat'}</span>
          </Button>
        </header>

        {/* Chat Area */}
        <div className="flex-1 overflow-hidden relative flex flex-col">
          <ScrollArea className="flex-1 px-4 py-6">
            <div className="max-w-3xl mx-auto space-y-6 pb-24">
              {/* Introduction Card */}
              {messages.length <= 1 && (
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-center space-y-4 p-8 rounded-3xl bg-card/30 border border-white/10 mb-8"
                >
                  <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mx-auto">
                    <Sparkles className="w-8 h-8 text-indigo-400" />
                  </div>
                  <h2 className="text-2xl font-bold">{t('aiWelcome') || 'Hello!'}</h2>
                  <p className="text-muted-foreground max-w-md mx-auto">
                    {t('aiWelcomeDesc') || 'I am your advanced AI assistant. Ask me anything about your school work, teaching materials, or administrative tasks.'}
                  </p>
                </motion.div>
              )}

              {/* Messages */}
              <AnimatePresence initial={false}>
                {messages.map((msg, index) => {
                  const isAi = msg.role === 'ai';
                  return (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`flex gap-4 ${isAi ? 'justify-start' : 'justify-end'}`}
                    >
                      {isAi && (
                        <Avatar className="h-8 w-8 mt-1 border border-white/10 shadow-sm flex-shrink-0">
                          <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-purple-600">
                            <Bot className="w-4 h-4 text-white" />
                          </AvatarFallback>
                        </Avatar>
                      )}
                      
                      <div className={`max-w-[85%] md:max-w-[75%] rounded-2xl p-4 shadow-sm ${
                        isAi 
                          ? 'bg-card/80 border border-white/10 rounded-tl-sm' 
                          : 'bg-indigo-600 text-white rounded-tr-sm'
                      }`}>
                        <div className="text-sm leading-relaxed overflow-x-auto whitespace-pre-wrap break-words">
                          {isAi ? formatText(msg.text) : msg.text}
                        </div>
                      </div>

                      {!isAi && (
                        <Avatar className="h-8 w-8 mt-1 border border-white/10 flex-shrink-0">
                          <AvatarFallback className="bg-zinc-700">
                            <User className="w-4 h-4 text-white" />
                          </AvatarFallback>
                        </Avatar>
                      )}
                    </motion.div>
                  );
                })}
              </AnimatePresence>

              {/* Loading Indicator */}
              {isLoading && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex gap-4 justify-start"
                >
                  <Avatar className="h-8 w-8 mt-1 border border-white/10 flex-shrink-0">
                    <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-purple-600">
                      <Bot className="w-4 h-4 text-white" />
                    </AvatarFallback>
                  </Avatar>
                  <div className="bg-card/80 border border-white/10 rounded-2xl rounded-tl-sm p-4 flex items-center gap-2">
                    <span className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                    <span className="w-2 h-2 bg-purple-500 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                    <span className="w-2 h-2 bg-blue-500 rounded-full animate-bounce"></span>
                    <span className="text-xs text-muted-foreground ml-2">{t('aiThinking') || 'Thinking...'}</span>
                  </div>
                </motion.div>
              )}
              
              <div ref={scrollRef} />
            </div>
          </ScrollArea>

          {/* Input Area */}
          <div className="p-4 bg-gradient-to-t from-background via-background to-transparent pt-10 mt-auto">
            <div className="max-w-3xl mx-auto">
              <form 
                onSubmit={handleSendMessage}
                className="relative flex items-center gap-2 p-2 bg-background/80 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl focus-within:border-indigo-500/50 transition-colors"
              >
                <div className="pl-2">
                   <Sparkles className="w-5 h-5 text-indigo-500" />
                </div>
                <Input
                  ref={inputRef}
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder={t('askAnything') || 'Ask a question...'}
                  className="border-none bg-transparent focus-visible:ring-0 px-3 py-3 h-auto max-h-32 shadow-none"
                  disabled={isLoading}
                  autoComplete="off"
                />
                <Button 
                  type="submit" 
                  size="icon"
                  disabled={!inputValue.trim() || isLoading}
                  className="h-10 w-10 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white shadow-lg shadow-indigo-500/20 shrink-0 transition-all"
                >
                  {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5 ml-0.5" />}
                </Button>
              </form>
              <p className="text-[10px] text-center text-muted-foreground mt-2 opacity-60">
                Cloud AI may generate inaccurate information. Please verify important details.
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CloudAIPage;