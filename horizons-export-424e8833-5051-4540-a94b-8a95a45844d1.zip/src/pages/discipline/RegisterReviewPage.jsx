import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, Filter, CheckCircle, XCircle, Calendar as CalendarIcon, User, Clock, Loader2, CheckSquare } from 'lucide-react';
import { format } from 'date-fns';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { Helmet } from 'react-helmet';
import { cn } from '@/lib/utils';

const RegisterReviewPage = () => {
  const { toast } = useToast();
  const userId = localStorage.getItem('userId');
  
  const [classes, setClasses] = useState([]);
  const [selectedClass, setSelectedClass] = useState(null);
  const [logs, setLogs] = useState([]);
  const [selectedLog, setSelectedLog] = useState(null);
  const [students, setStudents] = useState([]);
  const [absences, setAbsences] = useState({});
  const [loading, setLoading] = useState(true);
  const [studentsLoading, setStudentsLoading] = useState(false);

  useEffect(() => {
    fetchClasses();
  }, []);

  const fetchClasses = async () => {
    try {
      const { data, error } = await supabase
        .from('classes')
        .select('*')
        .eq('dm_id', userId);
      
      if (error) throw error;
      setClasses(data || []);
    } catch (error) {
      console.error('Error fetching classes:', error);
      toast({ variant: "destructive", title: "Error", description: "Failed to load classes" });
    } finally {
      setLoading(false);
    }
  };

  const fetchClassLogs = async (classId) => {
    setSelectedClass(classId);
    setLogs([]);
    setSelectedLog(null);
    
    try {
      // Fetch logbook entries for this class to show "Signed Registers"
      const { data, error } = await supabase
        .from('e_logbook_entries')
        .select('*, teachers(name)')
        .eq('class_id', classId)
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) throw error;
      setLogs(data || []);
    } catch (error) {
      console.error('Error fetching logs:', error);
    }
  };

  const handleLogSelect = async (log) => {
    setSelectedLog(log);
    setStudentsLoading(true);
    try {
      // 1. Get all students in class
      const { data: studentsData, error: studentError } = await supabase
        .from('students')
        .select('*')
        .eq('class_id', log.class_id)
        .order('name');
      
      if (studentError) throw studentError;

      // 2. Get absences for this specific date and class (and perhaps approximate time)
      // Since e_logbook_entries has created_at, we match DATE.
      const logDate = new Date(log.created_at).toISOString().split('T')[0];
      
      const { data: absenceData, error: absenceError } = await supabase
        .from('absences')
        .select('*')
        .eq('class_id', log.class_id)
        .eq('date', logDate);

      if (absenceError) throw absenceError;

      // Map absences to matricule for easy lookup
      const absenceMap = {};
      absenceData?.forEach(abs => {
        absenceMap[abs.student_matricule] = abs;
      });

      setStudents(studentsData || []);
      setAbsences(absenceMap);

    } catch (error) {
      console.error("Error details:", error);
      toast({ variant: "destructive", title: "Error", description: "Failed to load register details" });
    } finally {
      setStudentsLoading(false);
    }
  };

  const toggleAttendance = async (student) => {
    if (!selectedLog) return;

    const isAbsent = !!absences[student.matricule];
    const logDate = new Date(selectedLog.created_at).toISOString().split('T')[0];

    try {
      if (isAbsent) {
        // Remove absence -> Mark Present
        const { error } = await supabase
          .from('absences')
          .delete()
          .eq('student_matricule', student.matricule)
          .eq('date', logDate)
          .eq('class_id', selectedLog.class_id);
        
        if (error) throw error;

        const newAbsences = { ...absences };
        delete newAbsences[student.matricule];
        setAbsences(newAbsences);
        
        toast({ title: "Marked Present", description: `${student.name} is now marked present.` });
      } else {
        // Add absence -> Mark Absent
        const { data, error } = await supabase
          .from('absences')
          .insert([{
            student_matricule: student.matricule,
            class_id: selectedLog.class_id,
            teacher_id: selectedLog.teacher_id,
            date: logDate,
            hours: 2, // Default assumption for a register block
            status: 'pending',
            school_id: parseInt(localStorage.getItem('schoolId'))
          }])
          .select()
          .single();

        if (error) throw error;

        setAbsences({
          ...absences,
          [student.matricule]: data
        });

        toast({ title: "Marked Absent", description: `${student.name} is marked absent.`, variant: "destructive" });
      }
    } catch (error) {
      console.error("Error toggling attendance:", error);
      toast({ variant: "destructive", title: "Error", description: "Could not update attendance." });
    }
  };

  return (
    <>
      <Helmet>
        <title>Register Review - Discipline Master</title>
      </Helmet>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Register Review</h1>
          <p className="text-muted-foreground">Monitor class registers and verify student attendance.</p>
        </div>

        <div className="grid gap-6 md:grid-cols-12 h-full">
          {/* Left Panel: Class & Log Selection */}
          <Card className="md:col-span-4 lg:col-span-3 h-fit glass">
            <CardHeader>
              <CardTitle>Select Class</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Select onValueChange={fetchClassLogs}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a class..." />
                </SelectTrigger>
                <SelectContent>
                  {classes.map((cls) => (
                    <SelectItem key={cls.id} value={cls.id}>{cls.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <div className="mt-6">
                <h4 className="text-sm font-medium mb-3 text-muted-foreground">Recent Registers</h4>
                {selectedClass ? (
                  <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
                    {logs.length === 0 ? (
                      <p className="text-sm text-muted-foreground italic">No registers found.</p>
                    ) : (
                      logs.map(log => (
                        <div 
                          key={log.id}
                          onClick={() => handleLogSelect(log)}
                          className={cn(
                            "p-3 rounded-lg border cursor-pointer transition-all hover:bg-accent",
                            selectedLog?.id === log.id ? "bg-orange-500/10 border-orange-500 text-orange-500" : "bg-background/50 border-transparent hover:border-white/10"
                          )}
                        >
                          <div className="flex justify-between items-start mb-1">
                            <span className="font-semibold text-sm">{log.subject}</span>
                            <span className="text-xs opacity-70">{format(new Date(log.created_at), 'HH:mm')}</span>
                          </div>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <User className="w-3 h-3" /> {log.teachers?.name}
                          </div>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
                            <CalendarIcon className="w-3 h-3" /> {format(new Date(log.created_at), 'MMM dd, yyyy')}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">Select a class to see registers.</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Right Panel: Student List */}
          <Card className="md:col-span-8 lg:col-span-9 glass min-h-[600px]">
            <CardHeader>
              <CardTitle>
                {selectedLog ? (
                  <div className="flex items-center justify-between">
                    <span>Attendance: {selectedLog.subject}</span>
                    <Badge variant="outline" className="ml-2">
                      {format(new Date(selectedLog.created_at), 'PPP')}
                    </Badge>
                  </div>
                ) : "Attendance Details"}
              </CardTitle>
              <CardDescription>
                {selectedLog ? `Register signed by ${selectedLog.teachers?.name}. Click students to toggle attendance.` : "Select a register from the left to view details."}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {!selectedLog ? (
                <div className="flex flex-col items-center justify-center h-[400px] text-muted-foreground opacity-50">
                  <CheckSquare className="w-16 h-16 mb-4" />
                  <p>No register selected</p>
                </div>
              ) : studentsLoading ? (
                <div className="flex justify-center items-center h-[400px]">
                  <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {students.map((student) => {
                    const isAbsent = !!absences[student.matricule];
                    return (
                      <motion.div
                        key={student.matricule}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        onClick={() => toggleAttendance(student)}
                        className={cn(
                          "flex items-center justify-between p-4 rounded-lg border cursor-pointer transition-all duration-200 select-none group",
                          isAbsent 
                            ? "bg-red-500/10 border-red-500/50 hover:bg-red-500/20" 
                            : "bg-green-500/5 border-green-500/20 hover:bg-green-500/10"
                        )}
                      >
                        <div>
                          <p className="font-medium text-sm">{student.name}</p>
                          <p className="text-xs text-muted-foreground">{student.matricule}</p>
                        </div>
                        <div className={cn(
                          "w-8 h-8 rounded-full flex items-center justify-center transition-colors",
                          isAbsent ? "text-red-500 bg-red-500/20" : "text-green-500 bg-green-500/20"
                        )}>
                          {isAbsent ? <XCircle className="w-5 h-5" /> : <CheckCircle className="w-5 h-5" />}
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
};

export default RegisterReviewPage;