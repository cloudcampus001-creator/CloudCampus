import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { GraduationCap, Save, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Helmet } from 'react-helmet';

const MarksPage = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [classes, setClasses] = useState([]);
  const [students, setStudents] = useState([]);
  const [selectedClass, setSelectedClass] = useState('');
  const [assessmentName, setAssessmentName] = useState('');
  const [totalMarks, setTotalMarks] = useState(20);
  const [marks, setMarks] = useState({}); // Map matricule -> mark
  const [subject, setSubject] = useState('');

  const teacherId = localStorage.getItem('userId');
  const schoolId = localStorage.getItem('schoolId');

  useEffect(() => {
    fetchClasses();
  }, []);

  useEffect(() => {
    if (selectedClass) {
      fetchStudents(selectedClass);
      const cls = classes.find(c => c.id.toString() === selectedClass);
      if (cls) setSubject(cls.defaultSubject);
    }
  }, [selectedClass]);

  const fetchClasses = async () => {
    try {
      const { data, error } = await supabase
        .from('timetables')
        .select('class_id, subject, classes(id, name)')
        .eq('teacher_id', teacherId);

      if (error) throw error;

      const uniqueClasses = [];
      const seen = new Set();
      data?.forEach(item => {
        if (item.classes && !seen.has(item.class_id)) {
          seen.add(item.class_id);
          uniqueClasses.push({ ...item.classes, defaultSubject: item.subject });
        }
      });
      setClasses(uniqueClasses);
    } catch (error) {
      console.error('Error fetching classes:', error);
    }
  };

  const fetchStudents = async (classId) => {
    const { data, error } = await supabase
      .from('students')
      .select('*')
      .eq('class_id', classId)
      .order('name');
    
    if (error) console.error(error);
    else {
      setStudents(data || []);
      // Reset marks
      setMarks({});
    }
  };

  const handleMarkChange = (matricule, value) => {
    if (value === '' || (Number(value) >= 0 && Number(value) <= totalMarks)) {
      setMarks(prev => ({ ...prev, [matricule]: value }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!selectedClass || !assessmentName || !subject) {
      toast({ variant: "destructive", title: "Error", description: "Please fill all required fields." });
      return;
    }

    setLoading(true);
    try {
      const marksData = Object.entries(marks)
        .filter(([_, mark]) => mark !== '' && mark !== undefined)
        .map(([matricule, mark]) => ({
          student_matricule: matricule,
          teacher_id: parseInt(teacherId),
          class_id: parseInt(selectedClass),
          subject: subject,
          assessment_name: assessmentName,
          mark: parseFloat(mark),
          total_marks: parseFloat(totalMarks),
          school_id: parseInt(schoolId),
          created_at: new Date().toISOString()
        }));

      if (marksData.length === 0) {
        throw new Error("No marks entered.");
      }

      const { error } = await supabase
        .from('student_marks')
        .insert(marksData);

      if (error) throw error;

      toast({ title: "Success", description: "Marks submitted successfully!" });
      // Optional: Clear form or keep for review
      setAssessmentName('');
      setMarks({});
    } catch (error) {
      console.error('Error submitting marks:', error);
      toast({ variant: "destructive", title: "Error", description: error.message || "Failed to submit marks." });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>Enter Marks - Teacher Dashboard</title>
      </Helmet>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="max-w-4xl mx-auto space-y-6"
      >
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <GraduationCap className="h-8 w-8" />
            Enter Student Marks
          </h1>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="space-y-2">
            <Label>Select Class</Label>
            <Select value={selectedClass} onValueChange={setSelectedClass}>
              <SelectTrigger>
                <SelectValue placeholder="Class" />
              </SelectTrigger>
              <SelectContent>
                {classes.map((cls) => (
                  <SelectItem key={cls.id} value={cls.id.toString()}>
                    {cls.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Subject</Label>
            <Input 
              value={subject} 
              onChange={(e) => setSubject(e.target.value)}
              placeholder="Subject"
            />
          </div>
          <div className="space-y-2">
             <Label>Assessment Name</Label>
             <Input 
                value={assessmentName}
                onChange={(e) => setAssessmentName(e.target.value)}
                placeholder="e.g. Quiz 1, Mid-term"
             />
          </div>
        </div>
        
        {selectedClass && (
          <Card>
             <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Student List</CardTitle>
                <div className="flex items-center gap-2">
                   <Label>Total Marks:</Label>
                   <Input 
                      type="number" 
                      className="w-20" 
                      value={totalMarks}
                      onChange={(e) => setTotalMarks(e.target.value)}
                   />
                </div>
             </CardHeader>
             <CardContent>
                <form onSubmit={handleSubmit}>
                  <div className="space-y-4 max-h-[50vh] overflow-y-auto pr-2">
                    {students.map((student) => (
                      <div key={student.matricule} className="flex items-center justify-between p-3 border rounded-lg bg-card">
                        <div>
                           <p className="font-medium">{student.name}</p>
                           <p className="text-xs text-muted-foreground">{student.matricule}</p>
                        </div>
                        <div className="flex items-center gap-2">
                           <Input 
                              type="number"
                              placeholder="0"
                              className="w-20 text-right"
                              value={marks[student.matricule] || ''}
                              onChange={(e) => handleMarkChange(student.matricule, e.target.value)}
                              step="0.5"
                              min="0"
                              max={totalMarks}
                           />
                           <span className="text-muted-foreground text-sm">/ {totalMarks}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="mt-6">
                     <Button type="submit" className="w-full" disabled={loading || students.length === 0}>
                        {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                        Save Marks
                     </Button>
                  </div>
                </form>
             </CardContent>
          </Card>
        )}
      </motion.div>
    </>
  );
};

export default MarksPage;