import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Bell, Info, Calendar } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { Helmet } from 'react-helmet';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const ParentNotificationsPage = () => {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  
  const studentMatricule = localStorage.getItem('studentMatricule');
  const classId = localStorage.getItem('classId');
  const schoolId = localStorage.getItem('schoolId');

  useEffect(() => {
    fetchNotifications();
  }, []);

  const fetchNotifications = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .eq('school_id', schoolId)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Logic to filter relevant notifications
      // 1. Target Type: School (Everyone)
      // 2. Target Type: Class (My child's class)
      // 3. Target Type: Parent (Me directly)
      const filtered = data.filter(n => 
        n.target_type === 'school' ||
        (n.target_type === 'class' && n.target_id === parseInt(classId)) ||
        (n.target_type === 'parent' && n.target_id === parseInt(studentMatricule || 0))
      );

      setNotifications(filtered);
    } catch (error) {
      console.error('Error fetching notifications:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>Notifications - Parent Portal</title>
      </Helmet>
      
      <div className="p-6 max-w-4xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Notifications</h1>
          <p className="text-muted-foreground">Announcements from teachers and school administration.</p>
        </div>

        {loading ? (
          <div className="text-center py-12 text-muted-foreground">Loading...</div>
        ) : notifications.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground flex flex-col items-center">
            <Bell className="w-12 h-12 mb-4 opacity-20" />
            <p>No notifications found.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {notifications.map((n, idx) => (
              <motion.div
                key={n.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
              >
                <Card className="hover:border-indigo-500/30 transition-colors">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start gap-4">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-full bg-indigo-500/10 text-indigo-500">
                          <Info className="w-5 h-5" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{n.title}</CardTitle>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="secondary" className="text-[10px]">{n.sender_role}</Badge>
                            <span className="text-xs text-muted-foreground">From: {n.sender_name}</span>
                          </div>
                        </div>
                      </div>
                      <span className="text-xs text-muted-foreground whitespace-nowrap flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {new Date(n.created_at).toLocaleDateString()}
                      </span>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground leading-relaxed whitespace-pre-wrap">
                      {n.content}
                    </p>
                    {n.file_url && (
                      <a 
                        href={n.file_url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="inline-block mt-4 text-sm font-medium text-indigo-500 hover:underline"
                      >
                        View Attachment
                      </a>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </>
  );
};

export default ParentNotificationsPage;