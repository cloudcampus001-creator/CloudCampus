import React, { createContext, useContext, useEffect, useState, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';

const AuthContext = createContext(undefined);

export const AuthProvider = ({ children }) => {
  const { toast } = useToast();

  const [user, setUser] = useState(null);
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);

  // Helper to check session validity (e.g., 3 days max for "Persistent Login" logic)
  const isSessionValid = (currentSession) => {
    if (!currentSession) return false;
    
    // Optional: Enforce strict 3-day re-login policy if requested
    // Note: Supabase refresh tokens handle persistence automatically, 
    // but we can enforce a hard expiry on the client side if needed.
    const lastSignIn = new Date(currentSession.user.last_sign_in_at).getTime();
    const now = new Date().getTime();
    const threeDaysMs = 3 * 24 * 60 * 60 * 1000;

    // If users wants to enforce "Login within 3 days", we check this.
    // However, standard "Keep me signed in" usually just means "don't expire if active".
    // We'll trust the Supabase token validity primarily, but this logic is here if we need strictness.
    return true; 
  };

  const handleSession = useCallback(async (currentSession) => {
    if (currentSession && isSessionValid(currentSession)) {
      setSession(currentSession);
      setUser(currentSession.user ?? null);
    } else if (currentSession) {
      // Session invalid/expired by policy
      await supabase.auth.signOut();
      setSession(null);
      setUser(null);
      toast({
        title: "Session Expired",
        description: "Please log in again for security.",
        variant: "default",
      });
    } else {
      setSession(null);
      setUser(null);
    }
    setLoading(false);
  }, [toast]);

  useEffect(() => {
    let mounted = true;

    const initializeAuth = async () => {
      try {
        // 1. Check for existing session on load
        const { data: { session: initialSession }, error } = await supabase.auth.getSession();
        
        if (error) throw error;
        
        if (mounted) {
          await handleSession(initialSession);
        }
      } catch (error) {
        console.error('Auth initialization error:', error);
        if (mounted) setLoading(false);
      }
    };

    initializeAuth();

    // 2. Listen for auth changes (sign in, sign out, token refresh)
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, newSession) => {
        if (mounted) {
          // Handle specific events if needed
          if (event === 'SIGNED_OUT') {
            setSession(null);
            setUser(null);
            setLoading(false);
            // Clear sensitive local storage
            localStorage.removeItem('userRole');
            localStorage.removeItem('userId');
            localStorage.removeItem('schoolId');
            localStorage.removeItem('classId');
            localStorage.removeItem('userName');
            localStorage.removeItem('studentName');
          } else if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
            await handleSession(newSession);
          } else if (event === 'INITIAL_SESSION') {
             await handleSession(newSession);
          }
        }
      }
    );

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, [handleSession]);

  const signUp = useCallback(async (email, password, options) => {
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options,
    });

    if (error) {
      toast({
        variant: "destructive",
        title: "Sign up Failed",
        description: error.message || "Something went wrong",
      });
    }
    return { error };
  }, [toast]);

  const signIn = useCallback(async (email, password) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      toast({
        variant: "destructive",
        title: "Sign in Failed",
        description: error.message || "Something went wrong",
      });
    }
    return { error };
  }, [toast]);

  const signOut = useCallback(async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
      toast({
        variant: "destructive",
        title: "Sign out Failed",
        description: error.message || "Something went wrong",
      });
    }
    return { error };
  }, [toast]);

  const value = useMemo(() => ({
    user,
    session,
    loading,
    signUp,
    signIn,
    signOut,
    isAuthenticated: !!session && !!user
  }), [user, session, loading, signUp, signIn, signOut]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};